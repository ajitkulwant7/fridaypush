export interface PlayerPosition {
	x: number;
	y: number;
}
