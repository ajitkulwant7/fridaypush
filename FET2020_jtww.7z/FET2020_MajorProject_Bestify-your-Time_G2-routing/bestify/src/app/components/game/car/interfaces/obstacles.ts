export interface Obstacles {
	x: number;
	y: number;
	width: number;
	height: number;
	update: Function;
}
