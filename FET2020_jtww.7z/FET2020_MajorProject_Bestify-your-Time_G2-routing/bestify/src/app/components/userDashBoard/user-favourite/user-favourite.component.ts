import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-favourite',
  templateUrl: './user-favourite.component.html',
  styleUrls: ['./user-favourite.component.scss']
})
export class UserFavouriteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
