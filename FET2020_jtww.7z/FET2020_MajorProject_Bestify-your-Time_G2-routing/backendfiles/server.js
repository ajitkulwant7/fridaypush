const express = require("express");
const db = require("./app/models");

const nodemailer = require("nodemailer");
require('dotenv').config();

const bodyParser = require("body-parser");
const cors = require("cors");



const app = express();


app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended: true }));
require("./app/routes/user.route.js")(app);
require("./app/routes/quiz.route.js")(app);
require("./app/routes/quizscore.route.js")(app);
require("./app/routes/question.route.js")(app);
require("./app/routes/game.route.js")(app);

require("./app/routes/gameScore.route.js")(app);



require("./app/routes/homepage.route.js")(app);
require("./app/routes/gameScore.route.js")(app);



// var corsOptions = {
//   origin: "http://localhost:4200"
// };

// app.use(cors(corsOptions));

// app.use(function(req, res, next) {
//   res.header("Access-Control-Allow-Origin", "http://localhost:4200");
//   // res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//   next();
// });

app.use(cors());

// parse requests of content-type - application/json

db.sequelize.sync();



let transporter =nodemailer.createTransport({
  host: "172.27.172.202",
  port: 25,
  secure: false,
  auth:{
    // user: process.env.EMAIL,
    // pass: process.env.PASSWORD
    user: process.env.EMAIL,
    pass: process.env.PASSWORD
  },
  tls: {
    // do not fail on invalid certs
    rejectUnauthorized: false
  }
});

let mailOptions ={
  from: process.env.EMAIL,
  to: 'meghama@cybage.com',
  subject: 'New Mail',
  text: 'New Mail'
};

transporter.verify(function(error, success) {
  if (error) {
    console.log(error);
  } else {
    console.log("Server is ready to take our messages");
  }
});

transporter.sendMail(mailOptions,function(err,data){
  if(err){
    console.log("Error occures",err);
  }else{
    console.log("Email send successfully....");
  }
});




//app.use(express.json()); 

// parse requests of content-type - application/x-www-form-urlencoded





// simple route
// app.get("/", (req, res) => {
//   res.json({ message: "Welcome to bezkoder application." });
// });
// app.use(function(req, res, next) {
//   res.header("Access-Control-Allow-Origin", "*");
//   // res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//   next();
// });


// set port, listen for requests
const PORT = 8080;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});