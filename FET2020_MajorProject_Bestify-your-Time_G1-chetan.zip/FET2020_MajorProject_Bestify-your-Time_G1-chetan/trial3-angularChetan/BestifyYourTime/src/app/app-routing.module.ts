import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './commonComponents/login/login.component';
import { UsersComponent } from './users/components/users/users.component';
import { RegisterComponent } from './commonComponents/register/register.component';
import { ProfileComponent } from './commonComponents/profile/profile.component';
import { HomeComponent } from './commonComponents/home/home.component';
import { AdminComponent } from './admin/components/admin/admin.component';
import { AuthGuardService } from './services/auth-guard.service';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent, canActivate: [AuthGuardService]  },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'user', component: UsersComponent },
  { path: 'admin', component: AdminComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
