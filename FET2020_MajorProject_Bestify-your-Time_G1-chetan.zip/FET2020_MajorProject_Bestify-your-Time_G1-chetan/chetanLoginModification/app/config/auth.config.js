module.exports = {
    secret: "bestify-secret-key"
  };
